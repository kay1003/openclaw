#!/usr/bin/env bash
set -euo pipefail
BASE="/opt/openclaw-workspace/automation/email-digest"
source "$BASE/.env" 2>/dev/null || true
MAIL_MSG=$(python3 "$BASE/email_digest.py")
TOKEN_MSG=$(python3 "$BASE/token_usage_summary.py")
SEPARATOR="━━━━━━━━━━━━━━━━━━"
MSG="$TOKEN_MSG
$SEPARATOR
$MAIL_MSG"
openclaw message send --channel discord --target user:916630320726564864 --message "$MSG"
