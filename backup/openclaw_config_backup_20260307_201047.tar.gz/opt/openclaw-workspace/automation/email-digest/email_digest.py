#!/usr/bin/env python3
import os, imaplib, email, datetime, re
from email.header import decode_header, make_header

KEYWORDS = ["紧急","urgent","截止","deadline","合同","发票","invoice","验证码","verification","面试","interview","会议","meeting","付款","payment","逾期","异常"]


def dec(s):
    if not s:
        return ""
    try:
        return str(make_header(decode_header(s)))
    except Exception:
        return s


def score_mail(frm, subj, body_preview, vip):
    score = 0
    text = f"{frm}\n{subj}\n{body_preview}".lower()
    subj_l = (subj or '').strip().lower()

    # strong boost for subject prefixes user explicitly cares about
    for p in ('ibkr', 'interactivebrokers'):
        if subj_l.startswith(p):
            score += 8

    for v in vip:
        if v and v.lower() in text:
            score += 4
    for k in KEYWORDS:
        if k.lower() in text:
            score += 2
    if re.search(r"\b\d{1,2}:\d{2}\b|\d{4}[-/]\d{1,2}[-/]\d{1,2}", text):
        score += 1
    return score


def _select_inbox(M, preferred=None):
    """Return (ok, reason)."""
    candidates = []
    if preferred:
        candidates.extend([x.strip() for x in preferred.split(',') if x.strip()])

    # common mailbox names (including localized variants)
    candidates.extend([
        'INBOX', 'Inbox', '"INBOX"', '收件箱', '"收件箱"'
    ])

    tried = set()
    last_err = ''
    for box in candidates:
        if box in tried:
            continue
        tried.add(box)
        try:
            typ, data = M.select(box)
        except Exception as e:
            last_err = str(e)
            continue
        if typ == 'OK':
            return True, ''
        if data:
            try:
                last_err = data[0].decode(errors='ignore')
            except Exception:
                last_err = str(data[0])

    # fallback: scan LIST output and prioritize folders flagged as \Inbox
    typ, data = M.list()
    if typ == 'OK' and data:
        inbox_lines = []
        other_lines = []
        for raw in data:
            try:
                line = raw.decode(errors='ignore')
            except Exception:
                line = str(raw)
            if '\\INBOX' in line.upper() or '\\INBOX' in line:
                inbox_lines.append(line)
            else:
                other_lines.append(line)

        for line in inbox_lines + other_lines:
            m = re.search(r'"([^"]+)"\s*$', line)
            if m:
                box = m.group(1)
                for name in (box, f'"{box}"'):
                    if name in tried:
                        continue
                    tried.add(name)
                    typ2, data2 = M.select(name)
                    if typ2 == 'OK':
                        return True, ''
                    if data2:
                        try:
                            last_err = data2[0].decode(errors='ignore')
                        except Exception:
                            last_err = str(data2[0])

            # last fallback: if line mentions INBOX token, try selecting INBOX
            if 'INBOX' in line.upper():
                typ3, data3 = M.select('INBOX')
                if typ3 == 'OK':
                    return True, ''
                if data3:
                    try:
                        last_err = data3[0].decode(errors='ignore')
                    except Exception:
                        last_err = str(data3[0])

    return False, last_err


def fetch_important(host, user, pwd, label, vip, inbox_hint=None):
    out = []
    err = ''
    if not (host and user and pwd):
        return out, f'[{label}] 凭据缺失'
    try:
        M = imaplib.IMAP4_SSL(host, 993)
        M.login(user, pwd)
    except Exception as e:
        err = f"[{label}] 登录失败：{e}"
        print(err)
        return out, err

    ok, reason = _select_inbox(M, inbox_hint)
    if not ok:
        M.logout()
        if reason:
            err = f"[{label}] 收件箱选择失败：{reason}"
        else:
            err = f"[{label}] 未找到可用收件箱(INBOX)"
        print(err)
        return out, err

    since = (datetime.datetime.now(datetime.UTC) - datetime.timedelta(days=2)).strftime('%d-%b-%Y')
    typ, data = M.search(None, f'(UNSEEN SINCE {since})')
    if typ != 'OK' or not data or not data[0]:
        M.logout()
        return out, ''
    ids = data[0].split()[-80:]
    for mid in reversed(ids):
        typ, msg_data = M.fetch(mid, '(RFC822)')
        if typ != 'OK' or not msg_data or not msg_data[0]:
            continue
        msg = email.message_from_bytes(msg_data[0][1])
        subj = dec(msg.get('Subject', ''))
        frm = dec(msg.get('From', ''))
        date = dec(msg.get('Date', ''))
        body_preview = ''
        try:
            if msg.is_multipart():
                for part in msg.walk():
                    ctype = part.get_content_type()
                    if ctype == 'text/plain' and 'attachment' not in str(part.get('Content-Disposition','')):
                        body_preview = part.get_payload(decode=True).decode(errors='ignore')[:200]
                        break
            else:
                body_preview = msg.get_payload(decode=True).decode(errors='ignore')[:200]
        except Exception:
            pass
        s = score_mail(frm, subj, body_preview, vip)
        if s >= 3:
            out.append({"label":label,"from":frm,"subject":subj,"date":date,"score":s})
    M.logout()
    out.sort(key=lambda x: x['score'], reverse=True)
    return out[:10], ''


def main():
    vip = [x.strip() for x in os.getenv('MAIL_VIP_SENDERS','').split(',') if x.strip()]
    allm = []
    warns = []

    disable_163 = os.getenv('MAIL_DISABLE_163', '0').strip() == '1'
    if not disable_163:
        m163, e163 = fetch_important(
            'imap.163.com',
            os.getenv('MAIL_163_USER'),
            os.getenv('MAIL_163_PASS'),
            '163',
            vip,
            os.getenv('MAIL_163_INBOX', 'INBOX,收件箱,INBOX.收件箱')
        )
        allm += m163
        if e163:
            warns.append(e163)
    else:
        warns.append('[163] 已按配置跳过（MAIL_DISABLE_163=1）')

    mg, eg = fetch_important(
        'imap.gmail.com',
        os.getenv('MAIL_GMAIL_USER'),
        os.getenv('MAIL_GMAIL_PASS'),
        'Gmail',
        vip,
        os.getenv('MAIL_GMAIL_INBOX', 'INBOX')
    )
    allm += mg
    if eg:
        warns.append(eg)

    allm.sort(key=lambda x: x['score'], reverse=True)

    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    if not allm:
        lines = [f"【邮件日报 {now}】"]
        if warns:
            lines.append('注意：本次有邮箱拉取失败，以下结论仅基于可访问邮箱。')
            lines.extend([f"- {w}" for w in warns])
        lines.append('近24-48小时未发现高优先级未读邮件。')
        print('\n'.join(lines))
        return

    lines = [f"【邮件重要摘要 {now}】", f"共 {len(allm)} 封高优先级未读邮件（展示前{min(8,len(allm))}封）："]
    for i,m in enumerate(allm[:8],1):
        lines.append(f"{i}. [{m['label']}] {m['subject']}")
        lines.append(f"   发件人: {m['from']}")
        lines.append(f"   时间: {m['date']} | 优先级分: {m['score']}")
    if warns:
        lines.append('')
        lines.append('拉取告警：')
        lines.extend([f"- {w}" for w in warns])
    print('\n'.join(lines))

if __name__ == '__main__':
    main()
