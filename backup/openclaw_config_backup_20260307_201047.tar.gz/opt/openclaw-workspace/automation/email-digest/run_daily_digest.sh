#!/usr/bin/env bash
set -euo pipefail
BASE="/opt/openclaw-workspace/automation/email-digest"
source "$BASE/.env" 2>/dev/null || true
MSG=$(python3 "$BASE/email_digest.py")
openclaw message send --channel discord --target user:916630320726564864 --message "$MSG"
